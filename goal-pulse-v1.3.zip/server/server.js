import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const app = express();
const port = Number(process.env.PORT || 3000);
const apiKey = process.env.API_FOOTBALL_KEY?.trim();
const publicDir = fileURLToPath(new URL('../public/', import.meta.url));
const CACHE_MS = 20_000;
const WINDOW_MS = 60_000;
const MAX_REQUESTS_PER_WINDOW = 30;
let liveCache = { expiresAt: 0, payload: null };
const clients = new Map();

app.disable('x-powered-by');
// Baseline browser security headers. The current prototype uses inline CSS/JS,
// so a strict Content-Security-Policy is intentionally deferred until assets are externalized.
app.use((_req, res, next) => {
  res.set('X-Content-Type-Options', 'nosniff');
  res.set('X-Frame-Options', 'DENY');
  res.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
});
// Render sits behind its own proxy. Locally, do not trust forwarded IP headers.
if (process.env.RENDER === 'true') app.set('trust proxy', 1);
else if (process.env.TRUST_PROXY === '1') app.set('trust proxy', 1);

app.use((req, res, next) => {
  const now = Date.now();
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  let entry = clients.get(ip);
  if (!entry || now - entry.startedAt >= WINDOW_MS) entry = { startedAt: now, count: 0 };
  entry.count += 1;
  clients.set(ip, entry);
  if (entry.count > MAX_REQUESTS_PER_WINDOW) {
    res.set('Retry-After', String(Math.max(1, Math.ceil((WINDOW_MS - (now - entry.startedAt)) / 1000))));
    return res.status(429).json({ error: 'rate_limited', message: 'Πολλά αιτήματα. Δοκίμασε ξανά σε λίγο.' });
  }
  if (clients.size > 2000) {
    for (const [key, value] of clients) {
      if (now - value.startedAt >= WINDOW_MS) clients.delete(key);
    }
  }
  next();
});

// Only the public directory is web-accessible. Server code and secrets stay outside it.
app.use(express.static(publicDir, { extensions: ['html'], dotfiles: 'deny', index: 'index.html' }));

app.get('/api/health', (_req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({ ok: true, providerConfigured: Boolean(apiKey), mode: apiKey ? 'provider-ready' : 'demo-only', liveCacheSeconds: CACHE_MS / 1000 });
});

app.get('/api/fixtures/live', async (_req, res) => {
  if (!apiKey) return res.status(503).json({ error: 'provider_not_configured', message: 'Set API_FOOTBALL_KEY on the server. No live data is currently available.' });
  if (liveCache.payload && Date.now() < liveCache.expiresAt) {
    res.set('Cache-Control', 'private, max-age=5');
    return res.json({ ...liveCache.payload, cached: true });
  }
  try {
    const response = await fetch('https://v3.football.api-sports.io/fixtures?live=all', {
      headers: { 'x-apisports-key': apiKey }, signal: AbortSignal.timeout(12_000)
    });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) return res.status(502).json({ error: 'provider_error', status: response.status, message: 'Ο πάροχος δεδομένων δεν απάντησε επιτυχώς.' });
    if (Array.isArray(body.errors) && body.errors.length) {
      return res.status(502).json({ error: 'provider_rejected_request', message: 'Ο πάροχος επέστρεψε σφάλμα αιτήματος.' });
    }
    const fixtures = Array.isArray(body.response) ? body.response : [];
    const payload = { source: 'API-Football', fetchedAt: new Date().toISOString(), results: body.results ?? fixtures.length, response: fixtures, cached: false };
    liveCache = { expiresAt: Date.now() + CACHE_MS, payload };
    res.set('Cache-Control', 'private, max-age=5');
    res.json(payload);
  } catch {
    res.status(502).json({ error: 'upstream_unavailable', message: 'Δεν ήταν δυνατή η λήψη ζωντανών αγώνων αυτή τη στιγμή.' });
  }
});

app.listen(port, '0.0.0.0', () => console.log(`Goal Plus server listening on port ${port}`));
