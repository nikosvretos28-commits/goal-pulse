# GOAL PULSE v1.4

- Added a responsive match-details modal instead of browser alert popups.
- Modal shows verified provider fields when a real fixture is available.
- Clearly labels xG/statistics and AI insights as unavailable until the relevant provider/AI integrations are implemented; does not fabricate values.
- Preserved the API health check, live fixture endpoint, and 30-second frontend refresh.

## Validation
- `node --check server/server.js`: passed.
- Frontend inline JavaScript syntax check: passed.
- Automated server tests could not run in this environment because `express` dependencies were not installed; dependency installation timed out. Run `npm install --prefix server` and `npm test` in CI/Render or a network-enabled environment.
