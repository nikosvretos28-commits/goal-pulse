# Goal Pulse / Goal Plus — v1.3

- Replaced the older homepage with the new responsive GOAL PULSE premium dark design.
- Added branded inline SVG logo, match cards, xG stats, filters, search, pressure-wave visualization, league list, and AI-insights concept panel.
- Kept the existing Express server, health endpoint, live-fixtures API proxy, rate limiting, and Render deployment configuration.
- All scores/fixtures shown in the homepage are demo placeholders until the frontend is connected to `/api/fixtures/live` and an API-Football key is configured in the deployment environment.

## Deploy

1. Upload/commit the contents of this folder to the existing `goal-pulse` repository (keep the folder structure).
2. In Render, deploy the existing `goal-plus` web service from that repository.
3. Add `API_FOOTBALL_KEY` as a secret environment variable in Render to enable the live-fixtures endpoint. Do not put the key in frontend files.
4. Verify `/api/health`; `providerConfigured` should be `true` once the key is set.


## Live feed integration
- The homepage now checks `/api/health` and requests `/api/fixtures/live` when the provider key is configured.
- Live match cards and the compact live feed render from API-Football responses and refresh every 30 seconds.
- Demo content remains clearly labelled when no provider key is configured; the page does not invent real scores or xG values.
