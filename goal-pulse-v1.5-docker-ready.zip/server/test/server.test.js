import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { setTimeout as delay } from 'node:timers/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const serverDir = path.resolve(here, '..');
const port = 31000 + Math.floor(Math.random() * 20000);
const origin = `http://127.0.0.1:${port}`;
let child;

before(async () => {
  child = spawn(process.execPath, ['server.js'], {
    cwd: serverDir,
    env: { ...process.env, PORT: String(port), API_FOOTBALL_KEY: '', RENDER: 'false', TRUST_PROXY: '0' },
    stdio: 'ignore'
  });
  child.once('error', (error) => { throw error; });
  const deadline = Date.now() + 8000;
  while (Date.now() < deadline) {
    if (child.exitCode !== null) throw new Error(`Server exited early: ${child.exitCode}`);
    try {
      const response = await fetch(`${origin}/api/health`);
      if (response.ok) return;
    } catch {}
    await delay(100);
  }
  throw new Error('Server did not become ready within 8 seconds');
});

after(async () => {
  if (child && child.exitCode === null) {
    child.kill('SIGTERM');
    await Promise.race([once(child, 'exit'), delay(2000)]);
    if (child.exitCode === null) child.kill('SIGKILL');
  }
});

test('health endpoint reports demo-only mode without a secret', async () => {
  const response = await fetch(`${origin}/api/health`);
  assert.equal(response.status, 200);
  const data = await response.json();
  assert.equal(data.ok, true);
  assert.equal(data.providerConfigured, false);
  assert.equal(data.mode, 'demo-only');
  assert.equal(response.headers.get('cache-control'), 'no-store');
});

test('live endpoint clearly refuses to fake data when no API key exists', async () => {
  const response = await fetch(`${origin}/api/fixtures/live`);
  assert.equal(response.status, 503);
  const data = await response.json();
  assert.equal(data.error, 'provider_not_configured');
  assert.equal(typeof data.message, 'string');
});

test('fixture statistics endpoint validates fixture IDs and requires a provider key', async () => {
  const invalid = await fetch(`${origin}/api/fixtures/not-a-number/statistics`);
  assert.equal(invalid.status, 400);
  assert.equal((await invalid.json()).error, 'invalid_fixture_id');
  const unavailable = await fetch(`${origin}/api/fixtures/12345/statistics`);
  assert.equal(unavailable.status, 503);
  assert.equal((await unavailable.json()).error, 'provider_not_configured');
});

test('public home page is served and server code is not exposed as a static file', async () => {
  const home = await fetch(`${origin}/`);
  assert.equal(home.status, 200);
  assert.match(home.headers.get('content-type') || '', /text\/html/);
  assert.match(await home.text(), /GOAL PULSE/);
  const source = await fetch(`${origin}/server.js`);
  assert.equal(source.status, 404);
});

test('baseline security headers are present', async () => {
  const response = await fetch(`${origin}/api/health`);
  assert.equal(response.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(response.headers.get('x-frame-options'), 'DENY');
  assert.equal(response.headers.get('referrer-policy'), 'strict-origin-when-cross-origin');
});
