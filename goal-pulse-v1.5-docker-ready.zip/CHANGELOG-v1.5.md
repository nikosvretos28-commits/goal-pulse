# Goal Pulse / Goal Plus v1.5

- Added a server-side endpoint for per-fixture statistics from API-Football.
- Added input validation, provider-key checks, bounded in-memory caching, and upstream timeout/error handling for statistics.
- Match details now request available match statistics and show only values returned by the provider, including xG only if the provider returns it.
- Added smoke coverage for invalid fixture IDs and missing provider configuration.
- Live fixtures remain on a 30-second frontend refresh; the server caches provider responses for 20 seconds.

## Still not included
- AI-generated match analysis or betting predictions.
- Guaranteed xG coverage for every league/fixture; availability depends on the data provider and subscription.
- A production deployment to the user's GitHub/Render account or an API key.
