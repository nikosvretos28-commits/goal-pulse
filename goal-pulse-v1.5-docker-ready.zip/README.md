# GOAL PULSE / GOAL PLUS — v1.5 deployment package

Greek-language football dashboard prototype with a Node/Express server proxy for API-Football live fixtures.

## Current state

- The website UI is in `public/index.html`.
- The server is in `server/server.js` and serves only the `public/` folder.
- `GET /api/health` reports whether an API key is configured.
- `GET /api/fixtures/live` returns provider fixtures only when a valid `API_FOOTBALL_KEY` is configured. It does not fabricate live scores.
- Demo match cards and demo AI-style alerts are clearly labelled as demo content. They are not real match data or validated predictions.
- A real API key is not included. The website can be deployed in demo-only mode first. When the provider key is configured, the homepage polls the live fixtures endpoint every 30 seconds and renders the returned live scores.

## Run locally

Requirements: Node.js 20 or newer.

```sh
npm install --prefix server
npm run check --prefix server
npm test --prefix server
npm start --prefix server
```

Open `http://localhost:3000`. Without an API key, the health endpoint should report `demo-only` and the live endpoint should return HTTP 503.

To enable live fixtures, set `API_FOOTBALL_KEY` in the server environment. Do not place it in `public/index.html`, commit it, or send it in chat. Confirm your provider plan covers the competitions you need.

## Deploy on Render

This repository includes `render.yaml` for a Node web service. The service can deploy in demo-only mode without a provider key. To deploy:

1. Upload this folder's contents to a GitHub repository (the repository root must contain `render.yaml`, `public/`, and `server/`).
2. In Render, choose **New → Blueprint** and connect that repository, then review and approve the service creation.
3. Wait for deployment and check `https://YOUR-SERVICE.onrender.com/api/health`. The homepage then switches to real live fixtures when `providerConfigured` is true.
4. To enable live data, open the service's Environment settings and add `API_FOOTBALL_KEY` as a secret environment variable, then redeploy.

Render requires an authorized account and repository access; this archive alone does not publish a public URL. Do not share account passwords or API keys in chat.

## Checks

GitHub Actions is configured to install dependencies, check server syntax, and run smoke tests on pushes and pull requests. The tests require npm dependencies to be installable. In an offline environment, the syntax checks can be run without installing packages, but the Express server tests cannot be completed until dependencies are installed.

## Security and limitations

- The included per-process rate limiter is a basic prototype safeguard, not a distributed production rate limiter.
- Before a public launch, add monitoring, stronger abuse protection, privacy/terms pages, and review API-provider licensing and quotas.
- There is no user login, subscription billing, database, or real prediction model in this version.


Version history: see `CHANGELOG-v1.4.md` and `CHANGELOG-v1.5.md`.


## v1.5 update
- Match details can request provider statistics through `/api/fixtures/:id/statistics`.
- Values such as xG are displayed only when returned by API-Football for that fixture.
- AI analysis is not yet implemented.
